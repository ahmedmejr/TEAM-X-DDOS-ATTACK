# FALLEGA TEAM TNIK EL KOL 

 cd DDOS-FALLEGA
 
 Python3 DOB.py 
 
 Ip 
 
 Port 
 
 FALLEGA TNIK EL KOL 
  

   

     
